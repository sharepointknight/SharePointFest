import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { SharePointData } from './sharepointdata';
import { FormsModule }   from '@angular/forms';

@NgModule({
  imports: [
    BrowserModule, FormsModule
  ],
  declarations: [
    SharePointData
  ],
  bootstrap: [ SharePointData ]
})
export class SharePointAppModule { }

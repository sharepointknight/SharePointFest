import { browserDynamicPlatform } from '@angular/platform-browser-dynamic';
import { enableProdMode } from '@angular/core';
import { SharePointAppModule } from './sharepointapp.module';
import { SharePointService } from './sharepointservice';
import {HTTP_PROVIDERS,Http, Response, Headers } from '@angular/http';

browserDynamicPlatform().bootstrapModule(SharePointAppModule, [HTTP_PROVIDERS]);

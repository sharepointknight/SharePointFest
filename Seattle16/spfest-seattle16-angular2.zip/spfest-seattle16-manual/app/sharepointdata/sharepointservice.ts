import {HTTP_PROVIDERS,Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/Rx';

@Injectable()
export class SharePointService
{
    private self = this;
    private Guid = new RegExp("^(\{{0,1}([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}\}{0,1})$");
    constructor(private _http:Http)
    {

    }
    getListItems(listName: string, webUrl:string, options?:any) : Promise<Array<any>>
    {
        var url:string = "";
        var promise:Promise<boolean>;

        webUrl = this.SanitizeWebUrl(webUrl);

        if (typeof (options) === "string")
            options = { $filter: options };

        var url = "/web/lists";
        if (this.Guid.test(listName))
        {
            listName = listName.replace(/\{|\}/gi, "");
            url += "(guid'" + listName + "')"
        }
        else
        {
            url += "/getbytitle('" + listName + "')";
        }
        url += "/items";

        if (typeof (options) !== "undefined") {
            var odata = "";
            for (var property in options) {
                if (options.hasOwnProperty(property)) {
                    if (property === "LoadPage") {
                        url = options[property];
                        break;
                    }
                    if (odata.length == 0)
                        odata = "?";
                    odata += property + "=" + options[property] + "&";
                }
            }
            if (odata.lastIndexOf("&") == odata.length - 1) {
                odata = odata.substring(0, odata.length - 1);
            }
            url += odata;
        }
        
        var headers = new Headers();
        headers.append("Accept","application/json; odata=verbose");
        url = webUrl + "_api" + url; 
        promise = this._http.get(url,{

        }).map((response:Response) => response.json().data).toPromise();

        var deff = new Promise<Array<any>>(function (resolve, reject) {
            promise.then(function (data:any) { resolve(this.GetJustTheData(data)) }, function (data) { reject(data) });
        });
        
        return deff;
    }
    GetJustTheData(value:any) {
            var tmp = value;
            if (typeof (tmp.data) !== "undefined") {
                tmp = tmp.data;
            }
            if (typeof (tmp.d) !== "undefined") {
                tmp = tmp.d;
            }
            if (typeof (tmp.results) !== "undefined")
                tmp = tmp.results;
            return tmp;
        }
    GetItemTypeForListName(name:string) {
        name = name.replace(/_/g, '_x005f_').replace(/-/g, '');
        return "SP.Data." + name.charAt(0).toUpperCase() + name.split(" ").join("").slice(1) + "ListItem";
    }
    SanitizeWebUrl(url:string) {
        if (typeof (url) == "undefined" || url == null || url == "")
            url = _spPageContextInfo.siteAbsoluteUrl;
        if (url.endsWith("/") === false)
            url += "/";
        return url;
    }
}
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/Rx');
var SharePointData = (function () {
    function SharePointData(_http) {
        this._http = _http;
        this.Title = "";
        this.Guid = new RegExp("^(\{{0,1}([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}\}{0,1})$");
        this.newBand = new Band();
        this.Bands = new Array();
        //this.Bands.push( new Band("Test","Test Desc","https://cdn0.vox-cdn.com/thumbor/dUhFuohIxvh-F4v3EKsjY3XSWIU=/cdn0.vox-cdn.com/uploads/chorus_asset/file/3893454/win10_skype_320x320.0.gif","Rock"));
    }
    SharePointData.prototype.ngOnInit = function () {
        this.getBands();
    };
    SharePointData.prototype.getBands = function () {
        var _this = this;
        this.getListItems("Bands", "/").then(function (x) { return _this.Bands = x.map(function (d) {
            return new Band(d["Title"], d["Description"], d["ImageUrl"], d["Category"]);
        }); });
    };
    SharePointData.prototype.addBand = function () {
        var _this = this;
        var item = {
            Title: this.newBand.Title,
            Description: this.newBand.Description,
            Category: this.newBand.Category,
            ImageUrl: this.newBand.ImageUrl
        };
        this.CreateListItem("Bands", "/", item).then(function (d) {
            _this.Bands.push(new Band(d["Title"], d["Description"], d["ImageUrl"], d["Category"]));
            _this.newBand = new Band();
        });
    };
    SharePointData.prototype.getListItems = function (listName, webUrl, options) {
        var url = "";
        var promise;
        webUrl = this.SanitizeWebUrl(webUrl);
        if (typeof (options) === "string")
            options = { $filter: options };
        var url = "/web/lists";
        if (this.Guid.test(listName)) {
            listName = listName.replace(/\{|\}/gi, "");
            url += "(guid'" + listName + "')";
        }
        else {
            url += "/getbytitle('" + listName + "')";
        }
        url += "/items";
        if (typeof (options) !== "undefined") {
            var odata = "";
            for (var property in options) {
                if (options.hasOwnProperty(property)) {
                    if (property === "LoadPage") {
                        url = options[property];
                        break;
                    }
                    if (odata.length == 0)
                        odata = "?";
                    odata += property + "=" + options[property] + "&";
                }
            }
            if (odata.lastIndexOf("&") == odata.length - 1) {
                odata = odata.substring(0, odata.length - 1);
            }
            url += odata;
        }
        var headers = new http_1.Headers({ 'Accept': 'application/json; odata=verbose' });
        var reqoptions = new http_1.RequestOptions({ headers: headers });
        url = webUrl + "_api" + url;
        promise = this._http.get(url, reqoptions).map(function (response) { return response.json().d.results; }).toPromise();
        var deff = new Promise(function (resolve, reject) {
            promise.then(function (data) { debugger; resolve(data); }, function (data) { reject(data); });
        });
        return deff;
    };
    SharePointData.prototype.GetItemTypeForListName = function (name) {
        name = name.replace(/_/g, '_x005f_').replace(/-/g, '');
        return "SP.Data." + name.charAt(0).toUpperCase() + name.split(" ").join("").slice(1) + "ListItem";
    };
    SharePointData.prototype.CreateListItem = function (listName, webUrl, item, hostUrl) {
        var itemType = this.GetItemTypeForListName(listName);
        var url = "/web/lists/getbytitle('" + listName + "')/items";
        //item["__metadata"] = { "type": itemType };
        webUrl = this.SanitizeWebUrl(webUrl);
        var headers = new http_1.Headers({
            'Accept': 'application/json; odata=verbose',
            'Content-Type': 'application/json',
            'X-RequestDigest': $("#__REQUESTDIGEST").val()
        });
        var reqoptions = new http_1.RequestOptions({ headers: headers });
        var promise;
        promise = this._http.post(webUrl + "_api" + url, item, reqoptions)
            .map(function (response) { return response.json().d; }).toPromise();
        var deff = new Promise(function (resolve, reject) {
            promise.then(function (data) { resolve(data); }, function (data) { reject(data); });
        });
        return deff;
    };
    SharePointData.prototype.SanitizeWebUrl = function (url) {
        if (typeof (url) == "undefined" || url == null || url == "")
            url = _spPageContextInfo.siteAbsoluteUrl;
        if (url.endsWith("/") === false)
            url += "/";
        return url;
    };
    SharePointData.prototype.Save = function () {
    };
    SharePointData = __decorate([
        core_1.Component({
            selector: 'sharepointdata',
            templateUrl: '/demo/spfestseattle16/sharepointdata.html',
            providers: [http_1.HTTP_PROVIDERS]
        }), 
        __metadata('design:paramtypes', [http_1.Http])
    ], SharePointData);
    return SharePointData;
}());
exports.SharePointData = SharePointData;
var Band = (function () {
    function Band(title, description, imageUrl, category) {
        this.Title = title;
        this.Description = description;
        this.ImageUrl = imageUrl;
        this.Category = category;
    }
    return Band;
}());
exports.Band = Band;
//# sourceMappingURL=sharepointdata.js.map
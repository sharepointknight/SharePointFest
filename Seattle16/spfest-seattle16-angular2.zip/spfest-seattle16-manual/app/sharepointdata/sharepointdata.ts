import { Component, OnInit } from '@angular/core';
import {HTTP_PROVIDERS,Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/Rx';

@Component({
  selector: 'sharepointdata',
  templateUrl: '/demo/spfestseattle16/sharepointdata.html',
  providers: [HTTP_PROVIDERS]
})
export class SharePointData  { 
    Bands:Band[];
    Title:string="";
    newBand:Band;
    SelectedBand:Band;

    ngOnInit()
    {
        this.getBands();
    }
    getBands()
    {
        this.getListItems("Bands","/").then((x:Array<any>) => this.Bands = x.map(function (d) {
            return new Band(d["Title"], d["Description"], d["ImageUrl"], d["Category"]);
        }));
    }
    addBand()
    {
        var item = {
            Title: this.newBand.Title,
            Description: this.newBand.Description,
            Category: this.newBand.Category,
            ImageUrl: this.newBand.ImageUrl
        }
        this.CreateListItem("Bands","/", item).then((d:any)=> {
            this.Bands.push(new Band(d["Title"], d["Description"], d["ImageUrl"], d["Category"]));
            this.newBand = new Band();
        });
    }

    constructor(private _http:Http) {
        this.newBand = new Band();

        this.Bands = new Array<Band>();
        //this.Bands.push( new Band("Test","Test Desc","https://cdn0.vox-cdn.com/thumbor/dUhFuohIxvh-F4v3EKsjY3XSWIU=/cdn0.vox-cdn.com/uploads/chorus_asset/file/3893454/win10_skype_320x320.0.gif","Rock"));
    }

    private Guid = new RegExp("^(\{{0,1}([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}\}{0,1})$");
    
    getListItems(listName: string, webUrl:string, options?:any) : Promise<Array<any>>
    {
        var url:string = "";
        var promise:Promise<boolean>;

        webUrl = this.SanitizeWebUrl(webUrl);

        if (typeof (options) === "string")
            options = { $filter: options };

        var url = "/web/lists";
        if (this.Guid.test(listName))
        {
            listName = listName.replace(/\{|\}/gi, "");
            url += "(guid'" + listName + "')"
        }
        else
        {
            url += "/getbytitle('" + listName + "')";
        }
        url += "/items";

        if (typeof (options) !== "undefined") {
            var odata = "";
            for (var property in options) {
                if (options.hasOwnProperty(property)) {
                    if (property === "LoadPage") {
                        url = options[property];
                        break;
                    }
                    if (odata.length == 0)
                        odata = "?";
                    odata += property + "=" + options[property] + "&";
                }
            }
            if (odata.lastIndexOf("&") == odata.length - 1) {
                odata = odata.substring(0, odata.length - 1);
            }
            url += odata;
        }

        let headers = new Headers({ 'Accept': 'application/json; odata=verbose' });
        let reqoptions = new RequestOptions({ headers: headers });

        url = webUrl + "_api" + url; 

        promise = this._http.get(url,reqoptions).map((response:Response) => response.json().d.results).toPromise();

        var deff = new Promise<Array<any>>(function (resolve, reject) {
            promise.then(function (data:any) { debugger; resolve(data) }, function (data) { reject(data) });
        });
        
        return deff;
    }
    GetItemTypeForListName(name:string) {
        name = name.replace(/_/g, '_x005f_').replace(/-/g, '');
        return "SP.Data." + name.charAt(0).toUpperCase() + name.split(" ").join("").slice(1) + "ListItem";
    }
    CreateListItem(listName:string, webUrl:string, item:any, hostUrl?:any) {
        var itemType = this.GetItemTypeForListName(listName);
        var url = "/web/lists/getbytitle('" + listName + "')/items";
        //item["__metadata"] = { "type": itemType };
        webUrl = this.SanitizeWebUrl(webUrl);

        let headers = new Headers(
            { 
                'Accept': 'application/json; odata=verbose', 
                'Content-Type': 'application/json',
                'X-RequestDigest': $("#__REQUESTDIGEST").val()
            });
        let reqoptions = new RequestOptions({ headers: headers });
        
        var promise;
        promise = this._http.post(webUrl + "_api" + url, item, reqoptions)
                .map((response:Response) => response.json().d).toPromise();

        var deff = new Promise<Array<any>>(function (resolve, reject) {
            promise.then(function (data:any) { resolve(data) }, function (data) { reject(data) });
        });
        
        return deff;
    }
    SanitizeWebUrl(url:string) {
        if (typeof (url) == "undefined" || url == null || url == "")
            url = _spPageContextInfo.siteAbsoluteUrl;
        if (url.endsWith("/") === false)
            url += "/";
        return url;
    }

    public Save()
    {

    }

}
export class Band {
    constructor(title?:string,description?:string,imageUrl?:string,category?:string){
        this.Title = title;
        this.Description = description;
        this.ImageUrl = imageUrl;
        this.Category = category;
    }
    
    Title:string;
    Description:string;
    ImageUrl:string;
    Category:string;
}
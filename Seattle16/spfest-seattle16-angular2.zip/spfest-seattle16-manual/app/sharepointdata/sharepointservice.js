"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var http_1 = require('@angular/http');
var core_1 = require('@angular/core');
require('rxjs/Rx');
var SharePointService = (function () {
    function SharePointService(_http) {
        this._http = _http;
        this.self = this;
        this.Guid = new RegExp("^(\{{0,1}([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}\}{0,1})$");
    }
    SharePointService.prototype.getListItems = function (listName, webUrl, options) {
        var url = "";
        var promise;
        webUrl = this.SanitizeWebUrl(webUrl);
        if (typeof (options) === "string")
            options = { $filter: options };
        var url = "/web/lists";
        if (this.Guid.test(listName)) {
            listName = listName.replace(/\{|\}/gi, "");
            url += "(guid'" + listName + "')";
        }
        else {
            url += "/getbytitle('" + listName + "')";
        }
        url += "/items";
        if (typeof (options) !== "undefined") {
            var odata = "";
            for (var property in options) {
                if (options.hasOwnProperty(property)) {
                    if (property === "LoadPage") {
                        url = options[property];
                        break;
                    }
                    if (odata.length == 0)
                        odata = "?";
                    odata += property + "=" + options[property] + "&";
                }
            }
            if (odata.lastIndexOf("&") == odata.length - 1) {
                odata = odata.substring(0, odata.length - 1);
            }
            url += odata;
        }
        var headers = new http_1.Headers();
        headers.append("Accept", "application/json; odata=verbose");
        url = webUrl + "_api" + url;
        promise = this._http.get(url, {}).map(function (response) { return response.json().data; }).toPromise();
        var deff = new Promise(function (resolve, reject) {
            promise.then(function (data) { resolve(this.GetJustTheData(data)); }, function (data) { reject(data); });
        });
        return deff;
    };
    SharePointService.prototype.GetJustTheData = function (value) {
        var tmp = value;
        if (typeof (tmp.data) !== "undefined") {
            tmp = tmp.data;
        }
        if (typeof (tmp.d) !== "undefined") {
            tmp = tmp.d;
        }
        if (typeof (tmp.results) !== "undefined")
            tmp = tmp.results;
        return tmp;
    };
    SharePointService.prototype.GetItemTypeForListName = function (name) {
        name = name.replace(/_/g, '_x005f_').replace(/-/g, '');
        return "SP.Data." + name.charAt(0).toUpperCase() + name.split(" ").join("").slice(1) + "ListItem";
    };
    SharePointService.prototype.SanitizeWebUrl = function (url) {
        if (typeof (url) == "undefined" || url == null || url == "")
            url = _spPageContextInfo.siteAbsoluteUrl;
        if (url.endsWith("/") === false)
            url += "/";
        return url;
    };
    SharePointService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], SharePointService);
    return SharePointService;
}());
exports.SharePointService = SharePointService;
//# sourceMappingURL=sharepointservice.js.map
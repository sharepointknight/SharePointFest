"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var sharepointapp_module_1 = require('./sharepointapp.module');
var http_1 = require('@angular/http');
platform_browser_dynamic_1.browserDynamicPlatform().bootstrapModule(sharepointapp_module_1.SharePointAppModule, [http_1.HTTP_PROVIDERS]);
//# sourceMappingURL=sharepointmain.js.map
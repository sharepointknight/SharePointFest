import { enableProdMode } from '@angular/core';

enableProdMode();

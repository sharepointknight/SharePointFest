"use strict";
var core_1 = require('@angular/core');
core_1.enableProdMode();
//# sourceMappingURL=main.js.map
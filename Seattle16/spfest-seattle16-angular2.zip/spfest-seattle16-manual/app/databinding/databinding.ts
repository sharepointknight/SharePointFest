import { Component } from '@angular/core';

@Component({
  selector: 'databinding',
  templateUrl: '/Demo/SPFestSeattle16/manual/app/databinding.html'
})
export class Databinding { 
    Title:string="";
    constructor(){
        
    }
    public Clicked()
    {
        alert(this.Title);
    }
}
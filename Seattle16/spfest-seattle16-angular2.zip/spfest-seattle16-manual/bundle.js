var SystemBuilder = require('systemjs-builder');
var argv = require('yargs').argv;
var builder = new SystemBuilder();

  builder.loadConfig('systemjs.config.js')
    .then(function() {
        //**** Bundle Common Files into common bundle ****
        var depOutputFile = argv.prod ? 'dist/common.min.js' : 'dist/common.js';
        return builder.bundle('(databinding & sharepoint)', depOutputFile, {
            minify: argv.prod,
            mangle: argv.prod,
            sourceMaps: argv.prod,
            rollup: argv.prod
        });
    })
    .then(function() {
        /**** Bundle ProdMode Files into prodMode bundle ****/
        var appSource = argv.prod ? 'prodMode - dist/common.min.js' : 'prodMode - dist/common.js';
        var appOutputFile = argv.prod ? 'dist/prodMode.min.js' : 'dist/prodMode.js';
        return builder.bundle(appSource, appOutputFile, {
            minify: argv.prod,
            mangle: argv.prod,
            sourceMaps: argv.prod,
            rollup: argv.prod
        });
    })
    .then(function() {
        /**** Bundle WP1 Files into databinding bundle ****/
        var appSource = argv.prod ? 'databinding - dist/common.min.js' : 'databinding - dist/common.js';
        var appOutputFile = argv.prod ? 'dist/databinding.min.js' : 'dist/databinding.js';
        return builder.bundle(appSource, appOutputFile, {
            minify: argv.prod,
            mangle: argv.prod,
            sourceMaps: argv.prod,
            rollup: argv.prod
        });
    })
    .then(function() {
        //**** Bundle WP2 Files into wp2 bundle ****
        var appSource = argv.prod ? 'sharepoint - dist/common.min.js' : 'sharepoint - dist/common.js';
        var appOutputFile = argv.prod ? 'dist/sharepoint.min.js' : 'dist/sharepoint.js';
        return builder.bundle(appSource, appOutputFile, {
            minify: argv.prod,
            mangle: argv.prod,
            sourceMaps: argv.prod,
            rollup: argv.prod
        });
    })
    .then(function() {
        console.log('bundle built successfully');
    }); 
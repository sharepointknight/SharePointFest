﻿(function (global) {

  // map tells the System loader where to look for things
  var map = {
    'prodMode':                   'app/prodMode',
    'databinding':                'app/databinding', // 'dist',
    'sharepoint':                 'app/sharepointdata', // 'dist',
    'sharepointservice':          './sharepointservice', // 'dist',
    '@angular':                   'node_modules/@angular',
    'rxjs':                       'node_modules/rxjs'
  };

  // packages tells the System loader how to load when no filename and/or no extension
  var packages = {
    'prodMode':                   { main: 'main.js',  defaultExtension: 'js' },
    'databinding':                { main: 'main.js',  defaultExtension: 'js' },
    'sharepoint':                 { main: 'sharepointmain.js',  defaultExtension: 'js' },
    'sharepointservice':          { main: 'sharepointservice.js',  defaultExtension: 'js' },
    'rxjs':                       { defaultExtension: 'js' }
  };

  var packageNames = [
    'common',
    'compiler',
    'core',
    'http',
    'platform-browser',
    'platform-browser-dynamic',
    'router',
    'router-deprecated',
    'upgrade',
    'forms'
  ];

  // add package entries for angular packages in the form '@angular/common': { main: 'index.js', defaultExtension: 'js' }
  packageNames.forEach(function(pkgName) {
    packages['@angular/'+pkgName] = { main: 'bundles/' + pkgName + '.umd.js', defaultExtension: 'js' };
  });

  var config = {
    bundles: {
      'dist/common.min' : [
        '@angular/common',
        '@angular/compiler',
        '@angular/core',
        '@angular/http',
        '@angular/platform-browser',
        '@angular/platform-browser-dynamic',
        '@angular/router',
        '@angular/router-deprecated',
        '@angular/testing',
        '@angular/upgrade'
      ],
     'dist/prodMode.min': ['app/prodMode'],
     'dist/databinding.min': ['app/databinding'],
     'dist/sharepoint.min': ['app/sharepointdata']
    },
    typescriptOptions: {
        "module": "system",
        "sourceMap": true
    },
    map: map,
    packages: packages,
    baseURL: '/SiteAssets'
  }

  // filterSystemConfig - index.html's chance to modify config before we register it.
  if (global.filterSystemConfig) { global.filterSystemConfig(config); }

  System.config(config);

})(this);
import { Component } from '@angular/core';

@Component({
  selector: 'databinding',
  templateUrl: './app/databinding.html'
})
export class Databinding { 
    Title:string="";
    constructor(){
        
    }
    public Clicked()
    {
        alert(this.Title);
    }
}
import { Component } from '@angular/core';
//import 'angular2-adal';
//import { AuthHelper } from './AuthHelper';

@Component({
  selector: 'home',
  template: `<h2>Home Away from home</h2>`
})
export class Home {
    //private authHelper:AuthHelper;
	constructor() {
	}
	
	login() {
		// Use the AuthHelper to start the login flow
		//this.authHelper.login();
	}
 }
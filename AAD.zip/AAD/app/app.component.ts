import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {AdalService} from "ng2-adal/services";
import { Config } from "./config"
//import 'angular2-adal';

@Component({
  selector: 'my-app',
  template: `<img src='/SPKnightHeader.png' width='100' /><br /><h1 class="title">SPFest Seattle</h1>
    <nav>
      <a routerLink="/" routerLinkActive="active">Home</a>
      <a routerLink="/events" routerLinkActive="active">Events</a>
      <!--<a routerLink="/messages" routerLinkActive="active">Messages</a>-->
      <a routerLink="/Login" routerLinkActive="active">Login</a>
    </nav>
    <router-outlet></router-outlet>`
})
export class AppComponent {
    constructor(private adalService:AdalService) {
        //this.adalService = service;
        this.adalService.init(Config.ADALConfig);
    }
 }

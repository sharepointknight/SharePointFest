"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var services_1 = require("ng2-adal/services");
var config_1 = require("./config");
//import 'angular2-adal';
var AppComponent = (function () {
    function AppComponent(adalService) {
        this.adalService = adalService;
        //this.adalService = service;
        this.adalService.init(config_1.Config.ADALConfig);
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "<img src='/SPKnightHeader.png' width='100' /><br /><h1 class=\"title\">SPFest Seattle</h1>\n    <nav>\n      <a routerLink=\"/\" routerLinkActive=\"active\">Home</a>\n      <a routerLink=\"/events\" routerLinkActive=\"active\">Events</a>\n      <!--<a routerLink=\"/messages\" routerLinkActive=\"active\">Messages</a>-->\n      <a routerLink=\"/Login\" routerLinkActive=\"active\">Login</a>\n    </nav>\n    <router-outlet></router-outlet>"
    }),
    __metadata("design:paramtypes", [services_1.AdalService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var services_1 = require("ng2-adal/services");
//import 'angular2-adal';
//import { AuthHelper } from './AuthHelper';
var Messages = (function () {
    //private authHelper:AuthHelper;
    function Messages(http, adalService) {
        this.http = http;
        this.adalService = adalService;
        this.Messages = [];
        this.adalService.handleWindowCallback();
    }
    Messages.prototype.ngOnInit = function () {
        this.getAuth();
    };
    Messages.prototype.getAuth = function () {
        var _this = this;
        if (this.adalService.getCachedToken("https://graph.microsoft.com") === null)
            this.adalService.acquireToken("https://graph.microsoft.com").subscribe(function (res) {
                _this.getMessages();
            });
        else
            this.getMessages();
    };
    Messages.prototype.getMessages = function () {
        var _this = this;
        var headers = new http_1.Headers();
        headers.append('Content-Type', 'application/json');
        headers.append("Authorization", "Bearer " + this.adalService.getCachedToken(""));
        this.http.get("https://graph.microsoft.com/v1.0/me/messages").subscribe(function (res) {
            _this.Messages = res.json().value;
        });
    };
    return Messages;
}());
Messages = __decorate([
    core_1.Component({
        selector: 'messages',
        template: "<h2>Messages</h2><br /><br />\n  <ul>\n    <li *ngFor=\"let message of Messages\">{{message.subject}}</li>\n  </ul>"
    }),
    __metadata("design:paramtypes", [services_1.AuthHttp, services_1.AdalService])
], Messages);
exports.Messages = Messages;
//# sourceMappingURL=messages.js.map
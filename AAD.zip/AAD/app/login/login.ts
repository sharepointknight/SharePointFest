import { Component } from '@angular/core';
import {AdalService} from "ng2-adal/services";

@Component({
  selector: 'login',
  template: `{{UserName}}<br/><button *ngIf="!IsAuthenticated" (click)="logIn()">Login</button>
        <button *ngIf="IsAuthenticated" (click)="logout()">Logout</button>`
})
export class Login {
	constructor(private adalService:AdalService) {
		this.adalService.handleWindowCallback();
		let resource = this.adalService.GetResourceForEndpoint("https://graph.microsoft.com")
			if (this.adalService.userInfo.isAuthenticated) {
				if(this.adalService.getCachedToken(resource)===null && location.href.indexOf("id_token=") < 0)
				this.adalService.acquireToken(resource).subscribe((res) => {
					debugger;
				});
			}		
	}
	
	public logIn() {
		this.adalService.login();
    }
    public logout(){
        this.adalService.logOut();
    }
	public get IsAuthenticated(){
        return this.adalService.userInfo.isAuthenticated;
    }
	public get UserName() {
        if(this.adalService.userInfo)
        {
            return this.adalService.userInfo.userName;
        } 

        return "Guest";
    }
 }
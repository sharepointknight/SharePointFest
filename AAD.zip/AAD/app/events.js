"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var services_1 = require("ng2-adal/services");
//import 'angular2-adal';
//import { AuthHelper } from './AuthHelper';
var Events = (function () {
    //private authHelper:AuthHelper;
    function Events(http, adalService) {
        this.http = http;
        this.adalService = adalService;
        this.events = [];
        this.adalService.handleWindowCallback();
    }
    Events.prototype.ngOnInit = function () {
        this.getAuth();
    };
    Events.prototype.getAuth = function () {
        var _this = this;
        if (this.adalService.getCachedToken("https://graph.microsoft.com") === null)
            this.adalService.acquireToken("https://graph.microsoft.com").subscribe(function (res) {
                _this.getEvents();
            });
        else
            this.getEvents();
    };
    Events.prototype.getEvents = function () {
        var _this = this;
        var headers = new http_1.Headers();
        headers.append('Content-Type', 'application/json');
        headers.append("Authorization", "Bearer " + this.adalService.getCachedToken(""));
        this.http.get("https://graph.microsoft.com/v1.0/me/events").subscribe(function (res) {
            _this.events = res.json().value;
        });
    };
    return Events;
}());
Events = __decorate([
    core_1.Component({
        selector: 'events',
        template: "<h2>Events</h2><br /><br />\n  <ul>\n    <li *ngFor=\"let event of events\">{{event.subject}}</li>\n  </ul>"
    }),
    __metadata("design:paramtypes", [services_1.AuthHttp, services_1.AdalService])
], Events);
exports.Events = Events;
//# sourceMappingURL=events.js.map
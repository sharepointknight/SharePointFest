import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { RouterModule, Routes, Router, RouterOutlet } from '@angular/router';
import { Login } from './login/login';
import { Home } from './home.component';
import { Events } from './events';
import { Messages } from './messages';
import { Http, HttpModule } from "@angular/http";
import {AdalService, AuthHttp} from 'ng2-adal/services';
import { Config } from "./config";

const appRoutes: Routes = [
  //{ path: 'hero/:id', component: HeroDetailComponent },
  { path: 'Login', component: Login },
  { path: 'events', component: Events },
  { path: 'messages', component: Messages },
  { path: '', component: Home }
];

@NgModule({
  imports:      [ 
    BrowserModule, 
    //FormsModule,
    HttpModule,
    RouterModule.forRoot(appRoutes) ],
  declarations: [ AppComponent, Login, Home, Events, Messages ],
  bootstrap: [ AppComponent ],
  providers:[RouterModule, HttpModule, AdalService, AuthHttp]
  
})
export class AppModule {
  constructor(router:Router, private adalService:AdalService) {
    this.adalService.init(Config.ADALConfig);
    this.adalService.handleWindowCallback();
	}

 }

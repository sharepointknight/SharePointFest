"use strict";
var Config = (function () {
    function Config() {
    }
    Config["TenantID"] = "sharepointknight.onmicrosoft.com";
    Config["ClientID"] = "a3443388-48a0-4b65-b53c-ceda19cee4e0";
    Config["Resource"] = "https://graph.windows.net";
    Config.ADALConfig = {
        tenant: Config.TenantID,
        clientId: Config.ClientID,
        redirectUri: window.location.origin + '/Login',
        postLogoutRedirectUri: window.location.origin + '/',
        endpoints: {
            'https://graph.microsoft.com': 'https://graph.microsoft.com'
        },
        cacheLocation: "localStorage"
    };
    return Config;
}());
exports.Config = Config;
//# sourceMappingURL=config.js.map
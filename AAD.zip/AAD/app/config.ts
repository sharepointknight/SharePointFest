export class Config
{
    public static "TenantID":string = "sharepointknight.onmicrosoft.com";
    public static "ClientID":string = "a3443388-48a0-4b65-b53c-ceda19cee4e0";
    public static "Resource":string = "https://graph.windows.net";
    public static ADALConfig = {
            tenant: Config.TenantID,
            clientId: Config.ClientID,
            redirectUri: window.location.origin + '/Login',
            postLogoutRedirectUri: window.location.origin + '/',
            endpoints: {
                'https://graph.microsoft.com': 'https://graph.microsoft.com'
            },
            cacheLocation: "localStorage"
        }
}
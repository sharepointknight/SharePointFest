import { Component } from '@angular/core';
import { Http, Headers } from "@angular/http";
import {AdalService, AuthHttp} from "ng2-adal/services";
//import 'angular2-adal';
//import { AuthHelper } from './AuthHelper';

@Component({
  selector: 'events',
  template: `<h2>Events</h2><br /><br />
  <ul>
    <li *ngFor="let event of events">{{event.subject}}</li>
  </ul>`
})
export class Events {
  public events = [];
    //private authHelper:AuthHelper;
	constructor(private http:AuthHttp, private adalService:AdalService) {
    this.adalService.handleWindowCallback();
	}
	ngOnInit() {
    this.getAuth();
  }
  getAuth()
  {
    if(this.adalService.getCachedToken("https://graph.microsoft.com")===null)
      this.adalService.acquireToken("https://graph.microsoft.com").subscribe((res) => {
          this.getEvents();
        });
    else
      this.getEvents();
  }
	getEvents()
  {
    
    let headers:Headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append("Authorization","Bearer " + this.adalService.getCachedToken(""));
    this.http.get("https://graph.microsoft.com/v1.0/me/events").subscribe((res) => {
        this.events = res.json().value;
        });
  }
 }
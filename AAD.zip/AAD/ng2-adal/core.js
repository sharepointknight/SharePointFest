/**
 * ng2-adal - Use Azure AD Library - ADAL in Angular 2
 * @version v0.2.4
 * @link https://github.com/sureshchahal/angular2-adal#readme
 * @license MIT
 */
"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
var services_1 = require('./services');
__export(require('./services'));
exports.ANGULAR2_ADAL_PROVIDERS = [
    {
        provide: services_1.AdalService,
        useClass: services_1.AdalService
    }
];

//# sourceMappingURL=core.js.map

/**
 * ng2-adal - Use Azure AD Library - ADAL in Angular 2
 * @version v0.2.4
 * @link https://github.com/sureshchahal/angular2-adal#readme
 * @license MIT
 */
import {AdalService, AuthHttp} from './services';

export * from './services';

export const ANGULAR2_ADAL_PROVIDERS: any[] = [
    {
        provide: AdalService,
        useClass: AdalService
    }
];
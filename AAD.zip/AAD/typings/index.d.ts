/// <reference path="modules/debug/index.d.ts" />
/// <reference path="../node_modules/angular2-adal/typings/adal/index.d.ts" />